<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Bem-Sucedido</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Inclui os arquivos css do bootstrap 4 -->
</head>
<body class="font-family: 'Arial', sans-serif;">
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-6 mt-5 text-center">
                <h2>Envio bem-sucedido!</h2>
                <p>A nossa equipe de atendimento te respondera em breve.</p>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-sm-12 text-center">
                <a href="http://localhost/projeto_turma_integrante01-integrante02/Home/index.php" class="form-action btn btn-dark">Voltar</a>
            </div>
            <div class="col-sm-12">
                <a href="http://localhost/projeto_turma_integrante01-integrante02/Home/index.php" class="form-action btn btn-dark">Voltar</a>
            </div>
        </div>
    </div>
</body>
</html>
