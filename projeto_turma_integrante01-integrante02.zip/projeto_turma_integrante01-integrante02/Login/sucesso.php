<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Bem-Sucedido</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="font-family: 'Arial', sans-serif;">
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-6 mt-5 text-center">
                <h2>Login bem-sucedido!</h2>
                <p>Você está logado na sua conta.</p>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-sm-12 text-center">
                <a href="http://localhost/projeto_turma_integrante01-integrante02/Home/index.php" class="form-action btn btn-dark">Entrar</a>
            </div>
        </div>
    </div>
</body>
</html>